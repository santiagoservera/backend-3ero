package com.ucc.Crudservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
